var swiper = new Swiper(".sliderLogin", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    navigation: {
        nextEl: ".button-next-sa",
        prevEl: ".button-prev-sa",
    },
});